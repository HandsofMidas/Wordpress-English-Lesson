<script type="text/template" id='wpjelly-editor-layout'>
	<div class="_3RUBRwcRkj0E-N-gM9VX8s_wpjelly">
    <div class="JxzI-2Kvd9MEoZO5Wyrs_wpjelly" style="top: 9px; left: 60px; right: 59px;">
        <div class="_33aVwFPOtNhVfEhqw6JjpM_wpjelly"><a class="_3EDb8Ew7Zic_6y825xBiHQ_wpjelly" href="#/">Wp Jelly Template Importer</a></div>
        <nav class="_2bu3mj9tipEU6yuZxT7bD2_wpjelly">
            <ul class="_14ldS4GONDJxh3AnpPBJX9_wpjelly _wpjellyNavList" style="opacity: 1;">
                <li class="_3kdBDJ8iqP12wNsiIE5fTu_wpjelly "><a class="_1RpgDdKG1S9mFx90CkOypP_wpjelly wpjelly_editorGetCat active" href="block">Blocks</a></li>
                <li class="_3kdBDJ8iqP12wNsiIE5fTu_wpjelly "><a class="_1RpgDdKG1S9mFx90CkOypP_wpjelly wpjelly_editorGetCat wpjellyFirstCat" href="all">All</a></li>
                <?php $obj=WPJellyEditorAddon::getCatListEditor();?>
            </ul>
            <ul class="_14ldS4GONDJxh3AnpPBJX9_wpjelly _wpjellyNavList OAx3WmyjUg4Xy7qdA1_WW_wpjelly">
                <li class="_3kdBDJ8iqP12wNsiIE5fTu_wpjelly"><a href="#" class="_1RpgDdKG1S9mFx90CkOypP_wpjelly close-wpjelly-editor"><span class="dashicons dashicons-no"></span></a></li>
            </ul>
        </nav>
    </div>
    <div class="_2vmxquP_jizvLrLpCK_c5x_wpjelly">
        <div class="_2OwW856-9-FUqGxx4XBRMp_wpjelly">
            <div class="_1pLw1-7WEGRYGZQ9N4xT7y_wpjelly _3qm6EmqjLhek8Y8l8-I9Xo_wpjelly wpjelly-editor-loader" style="display:none;">
                <div class="dJ4j35gA2HilPTxnY0M9m"><span class="_2oM39E4E6Hy5OAO3aev9Qm" aria-label="Loading"></span></div>
            </div>
            <div class="_1pLw1-7WEGRYGZQ9N4xT7y_wpjelly" id="wpjelly-editor-container">
                <div>
                    <div class="_1LFtNh3LQY63C-DVwqC8xn_wpjelly wpjelly-popup-banner">
                        <div class="_2HmuOGC3Ithuf-sXf5b9fI_wpjelly">
                            <div class="_1yqUaTk94oRux2IOrSzyXP_wpjelly">
                                <h1 class="SopIxoGl2fWJBUXAjkupc_wpjelly">Free Template Kits for Elementor</h1>
                            </div>
                            <div class="_3KrrhC-E9jZRkP8DDDdQ9h_wpjelly">
                                <div class="_126zV04eoTDtbyC-BYLUAA_wpjelly">
                                    <span class="dashicons dashicons-search"></span>
                                    <input type="text" class="wpjelly-search" placeholder="Type to search...">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="_1beWw6dhJqtlaSujooBD-i_wpjelly  wpjelly-listing-container" data-type="block">
                    <?php $obj=WPJellyEditorAddon::getBlockList();?>
                </div>
            </div>
            <div class="_1pLw1-7WEGRYGZQ9N4xT7y_wpjelly wpjelly-inner" style="display:none;"></div>
            <div class="_1pLw1-7WEGRYGZQ9N4xT7y_wpjelly wpjelly-single-inner" style="display:none;"></div>
            <div class="_1pLw1-7WEGRYGZQ9N4xT7y_wpjelly" style="display:none;"></div>
        </div>
    </div>
</div>
</script>

